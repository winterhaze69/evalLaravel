<?php
namespace App;


use Illuminate\Database\Eloquent\Model;

class Salle extends Model
{
    public function disponible()
    {
        return $this->belongsToMany('App\Dispo');
    }
    public function localisations()
    {
        return $this->belongsToMany('App\Localisations');
    }
}
