<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Controllers\Salle as Salle;


class Salle extends Controller
{


}
