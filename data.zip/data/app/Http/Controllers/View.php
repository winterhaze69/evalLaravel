<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Salles as Salles;



class View extends Controller
{
  public function home()
  {
    return view('welcome');

  }
  public function showSalles()
    {
    //  dd($salles);
      $salles = Salle::all();
      return view('welcome', [
          "value" => $value,
          "content" => $content,
      ]);

    }
}
