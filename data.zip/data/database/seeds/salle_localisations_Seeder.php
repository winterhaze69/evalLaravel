<?php

use Illuminate\Database\Seeder;

class salle_localisations_Seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('localisations')->insert(
              [
                [
                  "value" => "local1",
                  "content" => "Paris",
                ],
                [
                  "value" => "local2",
                  "content" => "Londres",
                ],
                [
                  "value" => "local3",
                  "content" => "Brooklyn",
                ],
              ]
          );

}
}
